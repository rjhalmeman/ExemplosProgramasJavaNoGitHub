/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author a1817744
 */
public class GUI extends JFrame {
    Container cp;
    JLabel lbVazio1 = new JLabel("");
    JLabel lbBim1 = new JLabel("1o Bimestre");
    JLabel lbBim2 = new JLabel("2o Bimestre");
    JLabel lbBim3 = new JLabel("3o Bimestre");
    JLabel lbBim4 = new JLabel("4o Bimestre");
    JLabel lbDisciplina = new JLabel("Disciplina");
    JTextField tfBim1 = new JTextField(10);
    JTextField tfBim2 = new JTextField(10);
    JTextField tfBim3 = new JTextField(10);
    JTextField tfBim4 = new JTextField(10);
    JLabel lbVazio2 = new JLabel("");
    JButton btMedia = new JButton("Média");
    JTextField tfResult = new JTextField(10);
    JLabel lbVazio3 = new JLabel("");
    
    public GUI() {
        setSize(500,400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new GridLayout(3,5));
        
        cp.add(lbVazio1);
        cp.add(lbBim1);
        cp.add(lbBim2);
        cp.add(lbBim3);
        cp.add(lbBim4);
        cp.add(lbDisciplina);
        cp.add(tfBim1);
        cp.add(tfBim2);
        cp.add(tfBim3);
        cp.add(tfBim4);
        cp.add(lbVazio2);
        cp.add(btMedia);
        cp.add(tfResult);
        cp.add(lbVazio3);
        
        
        setLocationRelativeTo(null);
        setVisible(true);
        
        btMedia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Media media = new Media();
                media.setBim1(Double.valueOf(tfBim1.getText()));
                media.setBim2(Double.valueOf(tfBim2.getText()));
                media.setBim3(Double.valueOf(tfBim3.getText()));
                media.setBim4(Double.valueOf(tfBim4.getText()));
                tfResult.setText(String.valueOf(media.getResultado()));
            }
        });
    }
    
}
