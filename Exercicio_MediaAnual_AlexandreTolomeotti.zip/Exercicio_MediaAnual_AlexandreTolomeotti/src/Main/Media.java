/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author a1817744
 */
public class Media {
    double bim1;
    double bim2;
    double bim3;
    double bim4;
    double resultado;

    public double getBim1() {
        return bim1;
    }

    public void setBim1(double bim1) {
        this.bim1 = bim1;
    }

    public double getBim2() {
        return bim2;
    }

    public void setBim2(double bim2) {
        this.bim2 = bim2;
    }

    public double getBim3() {
        return bim3;
    }

    public void setBim3(double bim3) {
        this.bim3 = bim3;
    }

    public double getBim4() {
        return bim4;
    }

    public void setBim4(double bim4) {
        this.bim4 = bim4;
    }

    public double getResultado() {
        resultado = (bim1+bim2+bim3+bim4)/4;
        return resultado;
    }
    
}
