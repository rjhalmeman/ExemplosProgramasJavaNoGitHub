package Main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/**
 *
 * @author radames
 */
public class GUI extends JFrame {

    Container cp = new Container(); //será o container principal, nele serão adicionados os outros.
    JPanel painelNorte = new JPanel();
    JPanel painelSulEsquerda = new JPanel();
    JPanel painelSulDireita = new JPanel();
    JPanel painelSul = new JPanel();
    JPanel painelOeste = new JPanel();
    JPanel painelLeste = new JPanel();
    JPanel painelCentro = new JPanel();
    JLabel labelImagem = new JLabel();
    JLabel lbNorte = new JLabel("Label Norte");

    public GUI() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);//fecha o programa quando o usuário fechar a janela
        //atributos do form
        setSize(600, 600);
        setTitle("Este é o título da janela");
        cp = getContentPane(); //vincula o layout do frame com o componente cp. Fica mais fácil de controlar.
        cp.setLayout(new BorderLayout()); // layout com 5 posicoes - norte, sul, leste, oeste e centro

        //para cada posição, podemos colocar um "outro" painel
        painelNorte.setBackground(Color.yellow);
        painelSulEsquerda.setBackground(Color.pink);
        painelSulDireita.setBackground(Color.GREEN);
        painelSul.setLayout(new GridLayout(1, 2));
        painelSul.setBackground(Color.blue);
        painelSul.add(painelSulEsquerda);
        painelSul.add(painelSulDireita);

        int alinhamento = FlowLayout.RIGHT; // podem ser os números 1, 2 ou 3
        painelNorte.setLayout(new FlowLayout(alinhamento));
        painelNorte.add(lbNorte);

        painelCentro.add(labelImagem);

        painelOeste.setBackground(Color.red);
        painelLeste.setBackground(Color.MAGENTA);

        cp.add(painelNorte, BorderLayout.NORTH);
        cp.add(painelSul, BorderLayout.SOUTH);
        cp.add(painelLeste, BorderLayout.EAST);
        cp.add(painelOeste, BorderLayout.WEST);
        cp.add(painelCentro, BorderLayout.CENTER);

        
        //uma imagem
        try {
            ImageIcon icone = new javax.swing.ImageIcon(getClass().getResource("/icones/impressora_imprimindo_04.gif"));
            Image imagemAux;
            imagemAux = icone.getImage();
            icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
            labelImagem.setIcon(icone);
            labelImagem.setHorizontalAlignment(JLabel.CENTER);
        } catch (NullPointerException naoAchou) {
            System.out.println("não achou a imagem ..."+ naoAchou.getMessage());
        }
        painelCentro.setLayout(new GridLayout(1, 1));//alinha verticalmente
       
        setVisible(true);//faz "aparecer" a janela
        setLocationRelativeTo(null);//posiciona no centro do monitor

    }
}
